STEP 0：如果遇到圖片顯示不出來，請在解壓縮的時候在字碼頁中選取UTF-8。
STEP 1：請先將tripy.sql檔匯入phpMyAdmin。
STEP 2：將剩餘檔案以project形式匯入eclipse
